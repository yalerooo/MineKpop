
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.flashlight.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.BlockItem;

import net.mcreator.flashlight.item.FlashlightOnItem;
import net.mcreator.flashlight.item.FlashlightOffItem;
import net.mcreator.flashlight.FlashlightMod;

public class FlashlightModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, FlashlightMod.MODID);
	public static final RegistryObject<Item> FLASHLIGHT_LIGHT = block(FlashlightModBlocks.FLASHLIGHT_LIGHT, null);
	public static final RegistryObject<Item> FLASHLIGHT_OFF = REGISTRY.register("flashlight_off", () -> new FlashlightOffItem());
	public static final RegistryObject<Item> FLASHLIGHT_ON = REGISTRY.register("flashlight_on", () -> new FlashlightOnItem());

	private static RegistryObject<Item> block(RegistryObject<Block> block, CreativeModeTab tab) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties().tab(tab)));
	}
}
